# uc3m-periodismo-datos

Notas sobre periosimo de datos en uc3m
